Gender value is a compass on gender ideologies, made to use 8values' UI.
